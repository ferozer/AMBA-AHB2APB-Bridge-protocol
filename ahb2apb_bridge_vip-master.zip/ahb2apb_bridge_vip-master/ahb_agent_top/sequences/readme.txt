ahb sequences
