verification env
